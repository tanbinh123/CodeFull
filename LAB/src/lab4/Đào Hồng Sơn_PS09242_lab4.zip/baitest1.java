/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4.newpackage;

/**
 *
 * @author thanh
 */
public class baitest1 {
    public static void main(String[] args) {
        double i = 3;
        double tich = 1;
        while(i <= 6 ){
            tich = tich * i;
            i++;
        }
        System.out.print(tich);
    }
}
