/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.poly.Util;

/**
 *
 * @author thanh
 */
public class RequestAction {
    public static final String INSERT = "INSERT";
    public static final String LOGIN = "LOGIN";
    public static final String DELETE = "DELETE";
    public static final String UPDATE = "UPDATE";
    public static final String SEARCH = "SEARCH";
    public static final String BUY = "BUY";
    public static final String DELETECART = "DELETECART";
}
