/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_5;

/**
 *
 * @author thanh
 */
public class SinhVien {
    String Masv;
     String hoTen;
     String Email;
     String soDT;
     String diaChi;
     boolean gioiTinh;
    public SinhVien(String Masv, String hoTen, String Email, String soDT, String diaChi, boolean gioiTinh){
        this.Masv = Masv;
        this.hoTen = hoTen;
        this.Email = Email;
        this.soDT = soDT;
        this.diaChi = diaChi;
        this.gioiTinh = gioiTinh;
        
    }

}
